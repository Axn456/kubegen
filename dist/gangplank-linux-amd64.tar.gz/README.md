mise run build
